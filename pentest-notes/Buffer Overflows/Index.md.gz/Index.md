# Index
---
##### **This contains all the notes made for Buffer Overflow section.**
---
## Chapters(Methodology) 

#### 1 . [[Spiking]]
#### 2.  [[Fuzzing]]
#### 3.  [[Finding Offset]]
#### 4.  [[Badchars]]
#### 5. [[Jump Point]]
#### 6.   [[Shellcode]]

## Files

#### 1. [[Fuzz.py]]
#### 2. [[Offset.py]]
#### 3. [[Badchars.py]]
#### 4. [[Bytegen.py]]