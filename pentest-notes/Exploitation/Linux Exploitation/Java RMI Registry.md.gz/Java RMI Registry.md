# Java RMI Registry
---
# Enumeration

- The Java RMI Registry is typically found on the por 1099 and is represented as ***GNU Classpath grmiregistry***.

---
# Exploitation
- Use the metasploit module ***exploit/multi/misc/java_rmi_server***
- Set the necessary options and run the module.

> ***Important - Always run a comprehensive port scan since some services can be spoofed to run at a different port than their default ones.***