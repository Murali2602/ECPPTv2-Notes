# Heartbleed 
Heartbleed was a critical bug affecting ***OPENSSL*** versions ***1.0.1 to 1.0.1f*** which allowed for the reading of encrypted data stored in meomry due to incorrect impelmentation of ***TLS*** and ***DTLS*** protocols. 
***It also allowed for the reading of private keys responsible for securing the data over SSL.***

---
# Exploiting Heartbleed
- First, we need to identify the vulnerable OPENSSL Implementation. This can either be done with nmap scripts or metasploit.
>***Nmap: ***  nmap --script ssl-heartbleed 192.168.1.1
>***Metasploit: use auxilary/scanner/ssl/openssl_heartbleed***

- Remeber to set the ***action to dump*** and run the exploit
- Now u can view the loot file as .bin file 
- We can simply run - ***Strings [.bin File name]***
> Note: Try again if u dont get the leaked data since different content appears at different times within the leaked memory segment.